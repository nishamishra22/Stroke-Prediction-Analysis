import matplotlib.pyplot as plt
import numpy as np

# Customize these values as needed
classifiers = [
    'Random Forest\n(94.11% - Dataset 1\nJournal - 2023)',
    'Voting Classifier\n(95.56% - Dataset 1\nJournal - 2022)',
    'Random Forest\n(95% - Dataset 1\nJournal - 2021)',
    'Decision Tree\n(92.6% - Dataset 1\nJournal - 2021)',
    'Neural Network\n(78% - Dataset 1\nJournal - 2022)',
    'CATBoost\n(96.18% - Dataset 1\nOur Project)',
    'CATBoost\n(99% - Dataset 2\nOur Project)'
]
accuracies = [0.9411, 0.9556, 0.9500, 0.9260, 0.7800, 0.9618, 0.9900]
bar_color = 'lightcoral'

def create_bar_graph(classifiers, accuracies, bar_color, output_file):
    fig, ax = plt.subplots(figsize=(10, 6))
    bar_width = 0.5
    bar_positions = np.arange(len(classifiers))

    # Plotting the bars
    bars = ax.bar(bar_positions, accuracies, bar_width, align='center', alpha=0.7, color=bar_color)

    # Adding labels, title and grid
    ax.set_xlabel('Classifiers')
    ax.set_ylabel('Accuracy')
    ax.set_title('Visualizing Comparision of Best Accuracies')
    ax.set_xticks(bar_positions)
    ax.set_xticklabels(classifiers, rotation=45, ha='right')
    ax.set_ylim([0.75, 1.0])
    ax.grid(True, axis='y', linestyle='--', alpha=0.7)

    # Adding accuracy labels on top of each bar
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:.4f}', xy=(bar.get_x() + bar.get_width() / 2, height), 
                    xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')

    # Save the graph as an image
    plt.tight_layout()
    plt.savefig(output_file)
    plt.show()

# Call the function with your desired parameters
create_bar_graph(classifiers, accuracies, bar_color, 'classifier_accuracies_detailed.png')
