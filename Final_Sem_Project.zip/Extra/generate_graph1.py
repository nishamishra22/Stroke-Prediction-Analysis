import matplotlib.pyplot as plt
import numpy as np

# Customize these values as needed
classifiers = ['Bagging', 'Adaboost', 'XG Boost', 'G Boost', 'CATBoost']
accuracies = [0.947378, 0.949346, 0.956335, 0.960227, 0.961849]
bar_color = 'lightcoral'

def create_bar_graph(classifiers, accuracies, bar_color, output_file):
    fig, ax = plt.subplots()
    bar_width = 0.5
    bar_positions = np.arange(len(classifiers))

    # Plotting the bars
    bars = ax.bar(bar_positions, accuracies, bar_width, align='center', alpha=0.7, color=bar_color)

    # Adding labels, title and grid
    ax.set_xlabel('Classifiers')
    ax.set_ylabel('Accuracy')
    ax.set_title('Visualizing Accuracy for different Classifier')
    ax.set_xticks(bar_positions)
    ax.set_xticklabels(classifiers)
    ax.set_ylim([0.94, 0.97])
    ax.grid(True, axis='y', linestyle='--', alpha=0.7)

    # Adding accuracy labels on top of each bar
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:.6f}', xy=(bar.get_x() + bar.get_width() / 2, height), 
                    xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')

    # Save the graph as an image
    plt.tight_layout()
    plt.savefig(output_file)
    plt.show()

# Call the function with your desired parameters
create_bar_graph(classifiers, accuracies, bar_color, 'classifier_accuracies2.png')
