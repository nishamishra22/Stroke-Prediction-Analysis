import pandas as pd
import numpy as np

# Set seed for reproducibility
np.random.seed(42)

# Generate data for 50 patients
data = {
    'ID': range(1, 51),
    'Oxygen': np.random.randint(90, 101, size=50),
    'PulseRate': np.random.randint(65, 101, size=50),
    'Temperature': (96.0 + np.random.randint(0, 601, size=50) / 100.0).round(2)
}

# Create a DataFrame
df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
df.to_excel('realtime_health_data.xlsx', index=False)

print("Dataset generated and saved to 'realtime_health_data.xlsx'")
