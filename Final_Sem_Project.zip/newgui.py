import tkinter as tk
from tkinter import messagebox
import pickle
import numpy as np

# Load the pre-trained model
try:
    with open('CBmodel.pkl', 'rb') as file:
        model = pickle.load(file)
except Exception as e:
    messagebox.showerror("Model Load Error", f"Error loading the model: {e}")
    exit()

def fahrenheit_to_celsius(fahrenheit):
    return fahrenheit

def predict_stroke():
    try:
        # Get the input values
        temp_fahrenheit = float(entry_temp.get())
        pulse = float(entry_pulse.get())
        oxygen = float(entry_oxygen.get())
        
        # Convert temperature to Celsius
        temp_celsius = fahrenheit_to_celsius(temp_fahrenheit)
        
        # Prepare the input data for the model with a placeholder for patient_id
        # patient_id_placeholder = 0  # Placeholder value
        input_data = np.array([[temp_celsius, pulse, oxygen]])
        
        # Debug: Print input data
        print(f"Input Data: {input_data}")
        
        # Make the prediction
        prediction = model.predict(input_data)
        
        # Debug: Print prediction result
        print(f"Prediction: {prediction}")
        
        # Display the result
        if prediction[0] == 1:
            messagebox.showinfo("Prediction Result", "Stroke Prediction: Yes")
        else:
            messagebox.showinfo("Prediction Result", "Stroke Prediction: No")
    except ValueError as ve:
        messagebox.showerror("Input Error", f"Value error: {ve}")
    except Exception as e:
        messagebox.showerror("Prediction Error", f"An error occurred: {e}")

# Create the main window
root = tk.Tk()
root.title("Stroke Prediction")
root.geometry("380x220")

label_font = ("Helvetica", 14)
entry_font = ("Helvetica", 18)

# Create and place the labels and entries for input
tk.Label(root, text="Oxygen Level (%):", font=label_font).grid(row=0, column=0, padx=10, pady=10)
entry_temp = tk.Entry(root)
entry_temp.grid(row=0, column=1, padx=10, pady=10)

tk.Label(root, text="Pulse Rate (bpm):", font=label_font).grid(row=1, column=0, padx=10, pady=10)
entry_pulse = tk.Entry(root)
entry_pulse.grid(row=1, column=1, padx=10, pady=10)

tk.Label(root, text="Body Temperature (°F):", font=label_font).grid(row=2, column=0, padx=10, pady=10)
entry_oxygen = tk.Entry(root)
entry_oxygen.grid(row=2, column=1, padx=10, pady=10)

# Create and place the Predict button
predict_button = tk.Button(root, text="Predict", font=("Helvetica", 14), bg="black", fg="white", command=predict_stroke)
predict_button.grid(row=3, column=0, columnspan=2, pady=20)

# Run the main event loop
root.mainloop()